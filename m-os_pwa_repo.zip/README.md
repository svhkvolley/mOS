# m-OS PWA

Diese Version ist als PWA/App vorbereitet.

## GitHub Pages

1. Neues Repository erstellen
2. ZIP entpacken
3. Alle Dateien direkt ins Repository hochladen
4. Settings → Pages
5. Deploy from branch → main → /(root)
6. Pages-URL öffnen
7. In Chrome: App installieren / Zum Startbildschirm hinzufügen

Wichtig: `index.html`, `manifest.json`, `service-worker.js` und der Ordner `icons/` müssen direkt im Root liegen.
